"""Constants"""
GET_ATTR = "get_attr"
CALL_MODULE = "call_module"
CALL_FUNCTION = "call_function"
CALL_METHOD = "call_method"
PLACEHOLDER = "placeholder"
OUTPUT = "output"

CONV_BLOCK = "conv_block"
