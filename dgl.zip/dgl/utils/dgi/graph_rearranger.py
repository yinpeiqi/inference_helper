"""Graph Rearranger."""
# pylint: disable=comparison-with-callable
import operator
from torch.fx import GraphModule, Node
from torch.fx.passes.split_utils import split_by_tags

from .graph_replicator import GraphReplicator
from .constants import PLACEHOLDER, OUTPUT, CALL_MODULE, CONV_BLOCK


def arg_trace(a):
    """Trace the args for a node, return a node set."""
    ret = set()
    if isinstance(a, Node):
        ret.add(a)
    if isinstance(a, dict):
        for _, v in a.items():
            ret = ret.union(arg_trace(v))
    if isinstance(a, (list, tuple)):
        for v in a:
            ret = ret.union(arg_trace(v))
    elif isinstance(a, slice):
        ret = ret.union(arg_trace((a.start, a.step, a.stop)))
    return ret

class GraphRearranger():
    """The Graph Rearranger class.

    The graph rearranger can split the computation graph.
    """
    def __init__(self, graph_module: GraphModule):
        self.graph_module = graph_module

    def compute_message_degree(self):
        """Compute message degrees."""
        # Init the message degree.
        for node in self.graph_module.graph.nodes:
            node.message_degree = 0
        for node in self.graph_module.graph.nodes:
            for user in node.users:
                user.message_degree = max(user.message_degree, node.message_degree + (node.op == CALL_MODULE))
        # Fixed node that do not tagged (e.g., g.number_of_nodes()).
        for node in self.graph_module.graph.nodes.__reversed__():
            for arg in node.all_input_nodes:
                if arg.op in (PLACEHOLDER, CALL_MODULE):
                    continue
                if arg.message_degree != node.message_degree:
                    arg.message_degree = node.message_degree
        # Remove the last layer.
        output_message = max([node.message_degree for node in self.graph_module.graph.nodes])
        for node in self.graph_module.graph.nodes:
            if node.message_degree == output_message:
                node.message_degree -= 1

    def get_tag_by_message_degree(self):
        tags = []
        for node in self.graph_module.graph.nodes:
            if node.op == PLACEHOLDER or node.op == OUTPUT:
                continue
            node.tag = CONV_BLOCK + str(node.message_degree)
            if node.tag not in tags:
                tags.append(node.tag)
            print(node, node.args, node.tag)
        return tags

    def rearrange(self):
        """The rearrange function."""
        # First compute message degrees.
        self.compute_message_degree()
        # TODO: Input bindings could be done here.
        # Tag according to the message degrees.
        tags = self.get_tag_by_message_degree()
        splitted = split_by_tags(self.graph_module, tags)
        print(splitted.graph)
        print(splitted.conv_block0.graph)
        print(splitted.conv_block1.graph)
        return splitted
