"""Inference helper."""
import dgl
import torch
import torch.nn as nn
import tqdm
import gc

from .data_manager import DataManager
from .utils import get_new_arg_input, update_ret_output
from .splitter import split_module
from .tracer import dgl_symbolic_trace


class InferenceHelperBase():
    """Inference helper base class.

    This class is the base class for inference helper. Users can create an inference
    helper to compute layer-wise inference easily. The inference helper provides a
    simple interence, which users only need to call the ``inference`` function after
    create the InferenceHelper object.

    Parameters
    ----------
    root : torch.nn.Module
        The root model to conduct inference.
    device : torch.device
        The device to conduct inference computation.
    use_uva : bool
        Whether store graph and tensors in UVA.
    debug : bool
        Whether display debug messages.
    """
    def __init__(self, root: nn.Module, conv_modules = [], device = "cpu", \
                 use_uva = False, debug = False):
        # add a '_' in order not crash with the origin one.
        self._device = device
        self._use_uva = use_uva
        self._debug = debug
        graph_module = dgl_symbolic_trace(root, conv_modules)
        self._schema, self._splitted = split_module(graph_module, debug)
        self._funcs = [getattr(self._splitted, tag) for tag in self._schema.tags]
        self._data_manager = DataManager(device, use_uva)

    def _trace_output_shape(self, graph, *args):
        """Trace the intermiddle tensors' shapes. Helper function for ``inference``."""
        if graph.is_homogeneous:
            first_layer_inputs = (dgl.graph(([0], [0]), device=self._device),)
        else:
            # The heterogeneous graph support is not finished yet.
            data_dict = {}
            for canonical_etype in graph.canonical_etypes:
                data_dict[canonical_etype] = ([0], [0])
            first_layer_inputs = (dgl.heterograph(data_dict, device=self._device),)
        for arg in tuple(args):
            if arg is None:
                raise Exception("arguments could not be None.")
            else:
                first_layer_inputs += (arg[[0]].to(self._device),)
        arg2val_map = {}
        for val, arg_name in zip(first_layer_inputs, self._schema.first_layer_input):
            arg_node = self._schema.name2arg_map[arg_name]
            arg2val_map[arg_node] = val
        ret_shapes = [[] for _ in range(self._schema.layers_count)]
        for layer, func in zip(self._schema.layers, self._funcs):
            new_args = ()
            for arg_node in layer.inputs:
                new_args += (arg2val_map[arg_node],)
            output_vals = func(*new_args)
            if not isinstance(output_vals, tuple):
                output_vals = (output_vals,)
            if len(output_vals) != len(layer.outputs):
                raise Exception("output values not match with layer's output.")
            for val, arg_node in zip(output_vals, layer.outputs):
                if isinstance(val, torch.Tensor):
                    arg2val_map[arg_node] = val
                    ret_shapes[layer.layer_id].append((torch.Tensor, val.size()[1:]))
                else:
                    ret_shapes[layer.layer_id].append((val.__class__, None))
        return ret_shapes

    def compute(self, inference_graph, rets, layer, func):
        """Compute function.

        The abstract function for compute one layer convolution. Inside the inference
        function, the compute function is used for compute the message for next layer
        tensors. Users can override this function for their customize requirements.

        Parameters
        ----------
        inference_graph : DGLHeteroGraph
            The graph object for computation.
        rets : Tuple[Tensors]
            The predefined output tensors for this layer.
        layer : dgl.utils.split.schema.GraphLayer
            The layer information in the schema.
        func : Callable
            The function for computation.
        """
        raise NotImplementedError()

    def before_inference(self, graph, *args):
        """What users want to do before inference.

        Parameters
        ----------
        graph : DGLHeteroGraph
            The graph object.
        args : Tuple
            The input arguments, same as ``inference`` function.
        """
        pass

    def after_inference(self):
        """What users want to do after inference."""
        pass

    def init_ret(self, arg_node, shape):
        """The initization for ret.

        Users can override it if customize initization needs. For example use numpy memmap.

        Parameters
        ----------
        arg_node : dgl.utils.split.schema.ArgNode
            The argument node information.
        shape : Tuple[int]
            The shape of output tensors.

        Returns
        Tensor : Output tensor (empty).
        """
        return torch.zeros(shape)

    def clear_ret(self, arg_node):
        """The delation for ret.

        Users can override it if customize del needs. For example use numpy memmap.

        Parameters
        ----------
        arg_node : dgl.utils.split.schema.ArgNode
            The argument node information.
        """
        del self._data_manager[arg_node]

    def inference(self, inference_graph, *args):
        """The inference function.

        Call the inference function can conduct the layer-wise inference computation.

        inference_graph : DGLHeteroGraph
            The input graph object.
        args : Tuple
            The input arguments, should be the same as module's forward function.
        """
        self.before_inference(inference_graph, *args)
        if self._use_uva:
            for k in list(inference_graph.ndata.keys()):
                inference_graph.ndata.pop(k)
            for k in list(inference_graph.edata.keys()):
                inference_graph.edata.pop(k)

        first_layer_inputs = (inference_graph,) + tuple(args)
        if len(first_layer_inputs) != len(self._schema.first_layer_input):
            raise Exception("layer's input not match with args.")
        for val, arg_name in zip(first_layer_inputs, self._schema.first_layer_input):
            arg_node = self._schema.name2arg_map[arg_name]
            self._data_manager[arg_node] = val
        ret_shapes = self._trace_output_shape(inference_graph, *args)

        for layer, func in zip(self._schema.layers, self._funcs):

            rets = []
            for j, arg_node in enumerate(layer.outputs):
                cls, shape = ret_shapes[layer.layer_id][j]
                if cls == torch.Tensor:
                    ret_shape = (inference_graph.number_of_nodes(),) + tuple(shape)
                    ret = self.init_ret(arg_node, ret_shape)
                else:
                    ret = None
                rets.append(ret)
                self._data_manager[arg_node] = ret

            rets = self.compute(inference_graph, rets, layer, func)

            # delete intermediate val
            for arg_node in layer.inputs:
                if arg_node.input_layers[-1] == layer and \
                    arg_node.input_layers[0] != self._schema.get_layer(0):
                    self.clear_ret(arg_node)
            torch.cuda.empty_cache()

        outputs = ()
        for name in self._schema.last_layer_output:
            arg_node = self._schema.name2arg_map[name]
            outputs += (self._data_manager[arg_node],)

        self.after_inference()

        if len(outputs) == 1:
            return outputs[0]
        return tuple(outputs)


class InferenceHelper(InferenceHelperBase):
    """The InferenceHelper class.

    To construct an inference helper for customized requirements, users can extend the
    InferenceHelperBase class and write their own compute function (which can refer the
    InferenceHelper's implementation).

    Parameters
    ----------
    root : torch.nn.Module
        The model to conduct inference.
    batch_size : int
        The batch size for dataloader.
    device : torch.device
        The device to conduct inference computation.
    num_workers : int
        Number of workers for dataloader.
    use_uva : bool
        Whether store graph and tensors in UVA.
    debug : bool
        Whether display debug messages.
    """
    def __init__(self, root: nn.Module, conv_modules, batch_size, device, num_workers = 4, debug = False):
        super().__init__(root, conv_modules, device, debug=debug)
        self._batch_size = batch_size
        self._num_workers = num_workers

    def compute(self, graph, rets, layer, func):
        """Compute function.

        The basic compute function inside the inference helper. Users should not call this
        function on their own.

        Parameters
        ----------
        inference_graph : DGLHeteroGraph
            The graph object for computation.
        rets : Tuple[Tensors]
            The predefined output tensors for this layer.
        layer : dgl.utils.split.schema.GraphLayer
            The layer information in the schema.
        func : Callable
            The function for computation.

        Returns
        ----------
        Tuple[Tensors] : Output tensors.
        """
        sampler = dgl.dataloading.MultiLayerFullNeighborSampler(1)
        dataloader = dgl.dataloading.NodeDataLoader(
            graph,
            torch.arange(graph.number_of_nodes()).to(graph.device),
            sampler,
            batch_size=self._batch_size,
            device=self._device if self._num_workers == 0 else 'cpu',
            shuffle=False,
            drop_last=False,
            num_workers=self._num_workers)

        for input_nodes, output_nodes, blocks in tqdm.tqdm(dataloader):
            new_args = get_new_arg_input(layer.inputs, self._data_manager, \
                input_nodes, blocks[0], self._device)

            output_vals = func(*new_args)
            del new_args

            rets = update_ret_output(output_vals, rets, input_nodes, output_nodes, blocks)
            del output_vals

        return rets
