"""Graph Rewriter."""
import operator
from torch.fx import Graph

from .constants import OUTPUT, CALL_MODULE, CALL_FUNCTION


class GraphRewriter():
    """The Graph Rewriter class.

    Graph Rewriting functions could be implement under this class.
    """
    @staticmethod
    def blocks_to_graph(graph: Graph):
        """Transform blocks to a graph."""
        graph_list = None
        for node in graph.nodes:
            if node.op == CALL_MODULE:
                graph_obj = node.args[0]
                if graph_obj.op == CALL_FUNCTION and graph_obj.target == operator.getitem:
                    graph_list = graph_obj.args[0]
                    break
        if graph_list is not None:
            for node in graph.nodes:
                if node.op == CALL_FUNCTION and node.target == operator.getitem \
                    and node.args[0] == graph_list:
                    node.replace_all_uses_with(graph_list)
                    graph.erase_node(node)
        graph.lint()

    @staticmethod
    def remove_unused_nodes(graph: Graph):
        """Remove the unused nodes."""
        for node in graph.nodes.__reversed__():
            if node.op != OUTPUT:
                if len(node.users) == 0:
                    graph.erase_node(node)
        graph.lint()
