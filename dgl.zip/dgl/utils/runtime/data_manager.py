"""Data Manager."""
import torch
from dgl.utils import pin_memory_inplace, unpin_memory_inplace


class DataManager:
    """The Data Manager class."""
    def __init__(self, device, use_uva):
        self.arg2val_map = {}
        self.device = device
        self.use_uva = use_uva

    def __getitem__(self, arg_node):
        if arg_node not in self.arg2val_map:
            raise RuntimeError("schema not match with output.")
        return self.arg2val_map[arg_node]

    def __setitem__(self, arg_node, val):
        self.arg2val_map[arg_node] = val

    def __delitem__(self, arg_node):
        del self.arg2val_map[arg_node]

    def pin_data_inplace(self, layer):
        """Put data in Pinned memory."""
        for arg_node in layer.inputs:
            if isinstance(self[arg_node], torch.Tensor) and self[arg_node].device.type == 'cpu':
                pin_memory_inplace(self[arg_node])

    def unpin_data_inplace(self, layer):
        """Remove data from Pinned memory."""
        for arg_node in layer.inputs:
            if isinstance(self[arg_node], torch.Tensor) and self[arg_node].device.type == 'cpu':
                unpin_memory_inplace(self[arg_node])
