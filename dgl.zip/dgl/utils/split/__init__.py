"""Initialization."""
from .function_generator import FunctionGenerator
