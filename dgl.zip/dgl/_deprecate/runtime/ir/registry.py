"""Module for ir registry."""
from __future__ import absolute_import

IR_REGISTRY = {}
